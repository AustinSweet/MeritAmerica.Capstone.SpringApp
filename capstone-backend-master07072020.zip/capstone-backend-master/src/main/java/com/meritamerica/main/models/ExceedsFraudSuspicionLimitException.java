package com.meritamerica.main.models;

public class ExceedsFraudSuspicionLimitException extends Exception {
	public ExceedsFraudSuspicionLimitException() {
		super("ExceedsFraudSuspicionLimitException");
	}
}
