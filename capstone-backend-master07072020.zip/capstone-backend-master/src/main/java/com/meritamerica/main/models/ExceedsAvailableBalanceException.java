package com.meritamerica.main.models;

public class ExceedsAvailableBalanceException extends Exception {
	public ExceedsAvailableBalanceException() {
		super("Exceed Available Balance Exception");
	}
}
