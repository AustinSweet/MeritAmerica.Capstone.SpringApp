package com.meritamerica.main.models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Queue;

/**
 * This class has a public modifier and the main method which is the entry point of Merit America Bank. 
 * It calls and uses other classes and methods.
 * @author Huy Cam
 */

public class MeritAmericaBankApp {
//	public static void main(String[] args) {
//
//	}
	     
}